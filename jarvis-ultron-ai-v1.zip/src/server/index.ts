import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import {randomUUID} from 'node:crypto';
import type {ChatRequest,ChatResponse,Message,Source} from '../shared/types.js';

const app=express();app.use(cors());app.use(express.json({limit:'2mb'}));
const port=Number(process.env.PORT||8787);
const baseUrl=(process.env.AI_BASE_URL||'https://api.openai.com/v1').replace(/\/$/,'');

function systemPrompt(agent:'jarvis'|'ultron'|'consensus',tone:string){
 const identity=agent==='jarvis'?'JARVIS: analítico, elegante, estruturado, cuidadoso com fatos e incerteza.':agent==='ultron'?'ULTRON: direto, estratégico, crítico e pragmático.':'CONSENSO: sintetize JARVIS e ULTRON, elimine contradições e entregue a melhor resposta verificável.';
 return `${identity}\nResponda em português do Brasil por padrão. Seja coerente com a pergunta, não invente fatos, diferencie fatos de inferências e diga quando algo não puder ser confirmado. ${tone||''}`;
}

async function webSearch(q:string):Promise<Source[]>{
 if(process.env.BRAVE_SEARCH_API_KEY){
  const r=await fetch('https://api.search.brave.com/res/v1/web/search?q='+encodeURIComponent(q)+'&count=5',{headers:{'X-Subscription-Token':process.env.BRAVE_SEARCH_API_KEY,'Accept':'application/json'}});
  if(r.ok){const j:any=await r.json();return (j.web?.results||[]).slice(0,5).map((x:any)=>({title:x.title,url:x.url,snippet:x.description}));}
 }
 try{
  const r=await fetch('https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch='+encodeURIComponent(q)+'&srlimit=5&format=json&origin=*');
  if(r.ok){const j:any=await r.json();return (j.query?.search||[]).map((x:any)=>({title:x.title,url:'https://en.wikipedia.org/wiki/'+encodeURIComponent(x.title.replace(/ /g,'_')),snippet:String(x.snippet||'').replace(/<[^>]+>/g,'')}));}
 }catch{}
 return [];
}

async function ai(model:string,messages:{role:'system'|'user'|'assistant';content:string}[]){
 if(!process.env.AI_API_KEY)return 'Modo local: configure AI_API_KEY em .env para ativar o modelo de linguagem. A interface e o motor de contexto estão funcionando.';
 const r=await fetch(`${baseUrl}/chat/completions`,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${process.env.AI_API_KEY}`},body:JSON.stringify({model,messages,temperature:.35,max_tokens:1800})});
 if(!r.ok)throw new Error(`AI provider ${r.status}: ${await r.text()}`);
 const j:any=await r.json();return j.choices?.[0]?.message?.content||'Não houve resposta do modelo.';
}

app.get('/api/health',(_,res)=>res.json({ok:true,service:'jarvis-ultron-ai',time:new Date().toISOString()}));
app.post('/api/search',async(req,res)=>{try{res.json({sources:await webSearch(String(req.body.q||''))});}catch(e){res.status(500).json({error:String(e)});}});
app.post('/api/chat',async(req,res)=>{
 const b=req.body as ChatRequest; if(!b.message?.trim())return res.status(400).json({error:'message is required'});
 try{
  const sources=b.useWeb?await webSearch(b.message):[];
  const context=sources.length?'\n\nFontes encontradas na web:\n'+sources.map(s=>`- ${s.title}: ${s.url}\n  ${s.snippet||''}`).join('\n'):'';
  const history=(b.history||[]).slice(-12).map(m=>({role:m.role,content:m.content} as const));
  const answers:ChatResponse['answers']={};
  if(b.agent!=='consensus'){
   answers.jarvis=await ai(process.env.JARVIS_MODEL||'gpt-4.1-mini',[{role:'system',content:systemPrompt('jarvis',b.jarvisTone||'')},...history,{role:'user',content:b.message+context}]);
   answers.ultron=await ai(process.env.ULTRON_MODEL||'gpt-4.1-mini',[{role:'system',content:systemPrompt('ultron',b.ultronTone||'')},...history,{role:'user',content:b.message+context}]);
  }else{
   const jarvis=await ai(process.env.JARVIS_MODEL||'gpt-4.1-mini',[{role:'system',content:systemPrompt('jarvis',b.jarvisTone||'')},...history,{role:'user',content:b.message+context}]);
   const ultron=await ai(process.env.ULTRON_MODEL||'gpt-4.1-mini',[{role:'system',content:systemPrompt('ultron',b.ultronTone||'')},...history,{role:'user',content:b.message+context}]);
   answers.jarvis=jarvis;answers.ultron=ultron;
   answers.consensus=await ai(process.env.CONSENSUS_MODEL||'gpt-4.1-mini',[{role:'system',content:systemPrompt('consensus','Compare as duas respostas. Não favoreça uma persona. Corrija contradições e mantenha fontes quando existirem.')},{role:'user',content:`Pergunta: ${b.message}\n\nJARVIS:\n${jarvis}\n\nULTRON:\n${ultron}${context}`}]);
  }
  const out:ChatResponse={answers,sources};res.json(out);
 }catch(e){res.status(500).json({error:e instanceof Error?e.message:String(e)});}
});
app.listen(port,()=>console.log(`JARVIS × ULTRON API on http://localhost:${port}`));
