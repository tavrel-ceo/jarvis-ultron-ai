export type Agent = 'jarvis'|'ultron'|'consensus';
export type Message = {id:string;role:'user'|'assistant';agent?:Agent;content:string;createdAt:number;sources?:Source[]};
export type Source = {title:string;url:string;snippet?:string};
export type Session = {id:string;title:string;createdAt:number;updatedAt:number;messages:Message[];jarvisTone:string;ultronTone:string};
export type ChatRequest = {message:string;history?:Message[];agent?:Agent;jarvisTone?:string;ultronTone?:string;useWeb?:boolean};
export type ChatResponse = {answers:Partial<Record<Agent,string>>;sources:Source[]};
